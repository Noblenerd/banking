<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('middle_name')->nullable();
            $table->string('gender')->nullable();
            $table->string('dob')->nullable();
            $table->string('city')->nullable();
            $table->string('state')->nullable();
            $table->string('address')->nullable();
            $table->string('phone')->nullable();
            $table->string('username')->nullable();
            $table->string('email')->nullable();
            $table->string('email_verify_code')->nullable();
            $table->string('email_verify_status')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('expires_at')->nullable();
            $table->string('transaction_pin')->nullable();
            $table->string('bvn')->nullable();
            $table->string('bvn_verify_code')->nullable();
            $table->string('bvn_verify_status')->nullable();
            $table->string('nin')->nullable();
            $table->string('nin_verify_code')->nullable();
            $table->string('nin_verify_status')->nullable();
            $table->string('kyc_status')->nullable();
            $table->string('balance')->nullable();
            $table->string('tier_id')->nullable();
            $table->string('account_type')->nullable();
            $table->string('groove_acc_number')->nullable();
            $table->string('settle_acc_number')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
