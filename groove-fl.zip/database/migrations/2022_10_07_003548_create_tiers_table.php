<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTiersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tiers', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('int_trns_limit_pt')->nullable();
            $table->string('int_trns_limit_pd')->nullable();
            $table->string('int_receiving_limit')->nullable();
            $table->string('ext_trns_limit')->nullable();
            $table->string('ext_receiving_limit')->nullable();
            $table->string('max_acc_balance')->nullable();
            $table->string('atm_withdraw_limit_pt')->nullable();
            $table->string('atm_withdraw_limit_pd')->nullable();
            $table->string('pos_limit_pt')->nullable();
            $table->string('pos_limit_pd')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tiers');
    }
}
