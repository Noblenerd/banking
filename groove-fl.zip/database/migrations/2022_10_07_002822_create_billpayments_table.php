<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBillpaymentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('billpayments', function (Blueprint $table) {
            $table->id();
            $table->string('trx_id')->nullable();
            $table->string('bill_type_id')->nullable();
            $table->string('amount')->nullable();
            $table->string('details')->nullable();
            $table->string('rrr')->nullable();
            $table->string('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('billpayments');
    }
}
